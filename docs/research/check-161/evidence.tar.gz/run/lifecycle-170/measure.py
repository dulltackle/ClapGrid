import subprocess,time,json,os,sys,hashlib
from pathlib import Path
out=Path('/home/forclaw/tmp/implement-161/lifecycle-170')/sys.argv[1];out.mkdir(parents=True,exist_ok=True)
command=['node','--import','tsx','--test','--test-concurrency=1','--test-name-pattern=开发检查接受未提交内容|默认日常命令单次退出|固定提交验收与开发目录','tests/check-runner.test.ts','tests/check-watch.test.ts','tests/verification-jobs.test.ts']
samples=[]
for i in range(3):
 start=time.monotonic();r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'NODE_DISABLE_COMPILE_CACHE':'1'});duration=time.monotonic()-start
 log=out/f'{i+1}.log';log.write_bytes(r.stdout);samples.append({'sample':i+1,'durationSeconds':duration,'exitCode':r.returncode,'log':str(log),'sha256':hashlib.sha256(r.stdout).hexdigest()});print(json.dumps(samples[-1]),flush=True)
 if r.returncode:break
(out/'samples.json').write_text(json.dumps({'command':command,'cwd':os.getcwd(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'cache':'NODE_DISABLE_COMPILE_CACHE=1','samples':samples},indent=2)+'\n')
