import subprocess,json,time
from pathlib import Path
root='/home/forclaw/.codex/worktrees/spec-161-tooling/ClapGrid';out=Path('/home/forclaw/tmp/implement-161/scheduling-171');results=[]
for name,args in [('default-green',['node','--import','tsx','--test','--test-name-pattern','固定核心单文件并发1或2与普通all默认','tests/playwright-runner.test.ts']),('typecheck',['npm','run','typecheck'])]:
 t=time.monotonic()
 with open(out/(name+'.log'),'w') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'args':args,'exitCode':r.returncode,'durationSeconds':time.monotonic()-t,'log':str(out/(name+'.log'))});(out/'development.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
