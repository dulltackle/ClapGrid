import subprocess,time,json,os,statistics,hashlib
from pathlib import Path
root=Path('/home/forclaw/.codex/worktrees/spec-161-tooling/ClapGrid');out=Path('/home/forclaw/tmp/implement-161/scheduling-171')
files=['tests/text-search.test.ts','tests/service.test.ts'];env=os.environ.copy();env.update(NODE_DISABLE_COMPILE_CACHE='1',CLAPGRID_BROWSER_BUILD_CACHE='0');env.pop('NODE_TEST_CONTEXT',None);env.pop('NODE_COMPILE_CACHE',None)
configs={}
for label,pool,split in [('threads','threads',False),('forks','forks',False),('projects','threads',True)]:
 test={'environment':'node','cache':False,'fsModuleCache':False,'pool':pool,'maxWorkers':1,'fileParallelism':False,'isolate':True,'retry':0,'allowOnly':False,'passWithNoTests':False,'includeTaskLocation':True,'include':files}
 if split:test['projects']=[{'test':{'root':str(root),'name':'logic' if n==0 else 'service','include':[f],'cache':False,'fsModuleCache':False,'pool':pool,'maxWorkers':1,'fileParallelism':False,'isolate':True}} for n,f in enumerate(files)]
 config={'root':str(root),'resolve':{'alias':{'@':str(root/'src/panel')}},'test':test}
 path=out/f'{label}.config.mjs';path.write_text('export default '+json.dumps(config)+';\n');configs[label]=path
samples=[]
identityScript=f"import{{executionIdentity}}from'{root}/scripts/test-evidence.mjs';import{{randomUUID}}from'node:crypto';console.log(JSON.stringify(executionIdentity({json.dumps(str(root))},randomUUID())));"
for label,config in configs.items():
 for n in range(1,4):
  prefix=out/f'{label}-{n}';t=time.monotonic();identity=json.loads(subprocess.check_output(['node','--input-type=module','-e',identityScript],cwd=root,env=env,text=True))
  args=['node','node_modules/vitest/vitest.mjs','run','--config',str(config),'--reporter=json','--outputFile',str(prefix)+'.native.json']
  with open(str(prefix)+'.log','w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  after=json.loads(subprocess.check_output(['node','--input-type=module','-e',identityScript],cwd=root,env=env,text=True));duration=time.monotonic()-t
  data=json.load(open(str(prefix)+'.native.json')) if Path(str(prefix)+'.native.json').exists() else {}
  results=data.get('testResults',[]);cases=[a for x in results for a in x.get('assertionResults',[])]
  valid=r.returncode==0 and data.get('success') and {x['name'] for x in results}=={str(root/f) for f in files} and len(cases)==6 and all(x['status']=='passed' for x in cases) and identity['source']==after['source']
  sample={'variant':label,'sample':n,'durationSeconds':duration,'runnerCount':1,'runnerMinutes':duration/60,'exitCode':r.returncode,'valid':valid,'cases':len(cases),'before':identity,'after':after,'config':str(config),'configSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'nativeReport':str(prefix)+'.native.json','command':args,'cache':'NODE_DISABLE_COMPILE_CACHE=1; CLAPGRID_BROWSER_BUILD_CACHE=0; Vitest cache=false/fsModuleCache=false','workers':1}
  samples.append(sample);(out/'vitest-samples.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2)+'\n');print(label,n,round(duration,3),valid,flush=True)
  if not valid:raise SystemExit('样本不完整；保留原件并停止')
summary={k:{'samplesSeconds':[x['durationSeconds'] for x in samples if x['variant']==k],'medianSeconds':statistics.median(x['durationSeconds'] for x in samples if x['variant']==k)} for k in configs}
(out/'vitest-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
