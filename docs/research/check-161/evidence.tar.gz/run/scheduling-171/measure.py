import subprocess,time,json,os,platform,statistics,datetime
from pathlib import Path
root='/home/forclaw/.codex/worktrees/spec-161-tooling/ClapGrid'
out=Path('/home/forclaw/tmp/implement-161/scheduling-171')
files=['tests/audio-panel.test.ts','tests/delete-confirm-focus.test.ts','tests/panel-update-panel.test.ts','tests/wide-panel.test.ts']
env=os.environ.copy();env.update(NODE_DISABLE_COMPILE_CACHE='1',CLAPGRID_BROWSER_BUILD_CACHE='0',BROWSERSLIST_IGNORE_OLD_DATA='true');env.pop('NODE_COMPILE_CACHE',None)
samples=[]
for workers in [1,2]:
 for n in range(1,4):
  prefix=out/f'c{workers}-{n}';env['CLAPGRID_TEST_REPORT']=str(prefix)+'.json';env['CLAPGRID_BROWSER_TIMINGS']=str(prefix)+'.timings.jsonl'
  args=['node','scripts/test-runner.mjs','--suite','all','--files',json.dumps(files),'--concurrency',str(workers)]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
  with open(str(prefix)+'.log','w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  duration=time.monotonic()-t
  data=json.load(open(str(prefix)+'.json')) if Path(str(prefix)+'.json').exists() else {}
  cases=data.get('actual',{}).get('cases',[])
  rows=[json.loads(x) for x in Path(str(prefix)+'.timings.jsonl').read_text().splitlines()];observed=[x for x in rows if x.get('event')=='case'];starts=[x for x in rows if x.get('event')=='worker-start'];stops=[x for x in rows if x.get('event')=='worker-stop']
  def dead(pid):
   try:os.kill(pid,0);return False
   except ProcessLookupError:return True
  valid=r.returncode==0 and data.get('status')=='passed' and len(cases)==9 and all(c['status']=='passed' and c.get('retry',0)==0 for c in cases) and len(observed)==9 and all(len({x[k] for x in observed})==9 for k in ['contextId','pageId','directory']) and all(x.get('contextClosed') and not Path(x['directory']).exists() for x in observed) and len(starts)==len(stops) and all(dead(x['chromePid']) for x in starts)
  sample={'workers':workers,'sample':n,'startedAt':started,'durationSeconds':duration,'runnerMinutes':duration/60,'runnerCount':1,'exitCode':r.returncode,'valid':valid,'caseCount':len(cases),'workerCount':len(starts),'uniqueContextCount':len({x['contextId'] for x in observed}),'uniquePageCount':len({x['pageId'] for x in observed}),'uniqueDirectoryCount':len({x['directory'] for x in observed}),'report':str(prefix)+'.json','timings':str(prefix)+'.timings.jsonl','command':args,'sourceIdentity':data.get('identity'),'environment':{'platform':platform.platform(),'cpuCount':os.cpu_count(),'nodeCompileCache':'disabled','browserBuildCache':'disabled','competingChecks':False}}
  samples.append(sample);(out/'samples.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2)+'\n');print(workers,n,round(duration,3),valid,flush=True)
  if not valid:raise SystemExit('测量不完整，保留原件并停止')
summary={f'c{w}':{'samplesSeconds':[x['durationSeconds'] for x in samples if x['workers']==w],'medianSeconds':statistics.median(x['durationSeconds'] for x in samples if x['workers']==w)} for w in [1,2]}
summary['changePercent']=(summary['c2']['medianSeconds']/summary['c1']['medianSeconds']-1)*100
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
